using Microsoft.Data.SqlClient;

namespace EconnectService;

// Reads from GP. It only touches our read-only views (aa_AssetApp_...).
public class GpReader
{
    public string ConnectionString { get; }

    public GpReader(IConfiguration config)
    {
        ConnectionString = config.GetConnectionString("Gp")
            ?? throw new Exception("The Gp connection string is missing in appsettings.json");
    }

    public async Task<List<ClassDto>> GetClassesAsync()
    {
        var list = new List<ClassDto>();
        using var conn = new SqlConnection(ConnectionString);
        await conn.OpenAsync();

        using var cmd = new SqlCommand("SELECT Code, Description FROM aa_AssetApp_Classes ORDER BY Code", conn);
        using var reader = await cmd.ExecuteReaderAsync();
        while (await reader.ReadAsync())
        {
            list.Add(new ClassDto { Code = reader.GetString(0), Description = reader.GetString(1) });
        }
        return list;
    }

    // Assets come in pages so a big company does not send everything in one go.
    public async Task<List<AssetDto>> GetAssetsAsync(int page, int pageSize)
    {
        if (page < 1) page = 1;
        if (pageSize < 1 || pageSize > 2000) pageSize = 500;

        var list = new List<AssetDto>();
        using var conn = new SqlConnection(ConnectionString);
        await conn.OpenAsync();

        var sql = @"SELECT AssetId, Barcode, Description, Class, Custodian, SerialNumber
                    FROM aa_AssetApp_Assets
                    ORDER BY AssetId
                    OFFSET @skip ROWS FETCH NEXT @take ROWS ONLY";
        using var cmd = new SqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@skip", (page - 1) * pageSize);
        cmd.Parameters.AddWithValue("@take", pageSize);

        using var reader = await cmd.ExecuteReaderAsync();
        while (await reader.ReadAsync())
        {
            list.Add(new AssetDto
            {
                AssetId = reader.GetString(0),
                Barcode = reader.GetString(1),
                Description = reader.GetString(2),
                Class = reader.GetString(3),
                Custodian = reader.GetString(4),
                SerialNumber = reader.GetString(5)
            });
        }
        return list;
    }

    // Returns the Asset ID if this barcode is already used as a label in GP, otherwise null.
    public async Task<string?> FindAssetIdByBarcodeAsync(string barcode)
    {
        using var conn = new SqlConnection(ConnectionString);
        await conn.OpenAsync();

        using var cmd = new SqlCommand("SELECT TOP 1 AssetId FROM aa_AssetApp_Assets WHERE Barcode = @b", conn);
        cmd.Parameters.AddWithValue("@b", barcode);
        var result = await cmd.ExecuteScalarAsync();
        return result as string;
    }

    // Numbering rule (assumed - confirm with the company, see open question in section 10):
    // prefix + 6 digit number, e.g. APP000001, APP000002 ...
    public async Task<string> GetNextAssetIdAsync(string prefix)
    {
        using var conn = new SqlConnection(ConnectionString);
        await conn.OpenAsync();

        var sql = "SELECT MAX(AssetId) FROM aa_AssetApp_Assets WHERE AssetId LIKE @p + '%'";
        using var cmd = new SqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@p", prefix);
        var highest = await cmd.ExecuteScalarAsync() as string;

        int number = 0;
        if (!string.IsNullOrEmpty(highest))
        {
            // take the digits after the prefix
            int.TryParse(highest.Substring(prefix.Length), out number);
        }
        return prefix + (number + 1).ToString("D6");
    }
}
